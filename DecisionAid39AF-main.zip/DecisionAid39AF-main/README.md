# Decision Aid
Practice application for CS39AF (Fall 2025)

Implementation Language: Java

Build Tool: Apache Ant

### Test
`ant test`

### Build
`ant jar`

### Run
`ant run`

or

`java -jar build/jar/DecisionAid.jar`

